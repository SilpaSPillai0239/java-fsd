package Sorting;

public class ExponentialSearch {
	
	    public static int exponentialSearch(int[] arr, int Key_element) {
	        int n = arr.length;

	        
	        if (arr[0] == Key_element) {
	            return 0;
	        }

	       
	        int i = 1;
	        while (i < n && arr[i] <= Key_element) {
	            i *= 2;
	        }

	       
	        int left = i / 2;
	        int right = Math.min(i, n - 1);

	        while (left <= right) {
	            int mid = left + (right - left) / 2;

	            if (arr[mid] == Key_element) {
	                return mid; 
	            }

	            if (arr[mid] < Key_element) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }

	        return -1; 
	    }

	    public static void main(String[] args) {
	        int[] array = { 10,30, 45, 50, 65, 70,90, 100 };
	        int target = 50;
	        int index = exponentialSearch(array, target);

	        if (index != -1) {
	            System.out.println("Element " + target + " found at index " + index);
	        } else {
	            System.out.println("Element " + target + " not found in the array");
	        }
	    }
	}


