package Sorting;

public class QuickSort {
    public static void main(String[] args) {
        int[] arr = {25,20,19,5, 2, 8, 12,30, 1, 6, 3};
        
        System.out.println(" array before sorting:");
        printArray(arr);
        
        quickSort(arr, 0, arr.length - 1);
        
        System.out.println("Sorted array:");
        printArray(arr);
    }
    
    
    
    public static int partition(int[] arr, int lower, int higher) {
        int pivot = arr[higher];
        int i = lower - 1;
        
        for (int j = lower; j < higher; j++) {
            if (arr[j] < pivot) {
                i++;
                swap(arr, i, j);
            }
        }
        
        swap(arr, i + 1, higher);
        
        return i + 1;
    }
    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            int index_partition = partition(arr, low, high);
            
            quickSort(arr, low, index_partition - 1);
            quickSort(arr, index_partition + 1, high);
        }
    }
    
    public static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}
