package Sorting;

public class LinearSearch {
    private static int Linear_Search(int[] arr, int key_element) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == key_element) {
                return i; 
            }
        }
        return -1; 
    }

    public static void main(String[] args) {
        int[] array = { 10,30, 45, 50, 65, 70, 75,80,85, 90,95, 100 };
        int key_element = 75;
        int index =  Linear_Search(array, key_element);

        if (index != -1) {
            System.out.println("Element " + key_element + " found at index of" +" "+ index);
        } else {
            System.out.println("Element " + key_element + " not found in the array");
        }
    }
}
