package com.test.example;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
        
    @Autowired
    ProductRepo repo;
      
    public Product insert(Product e) {
		return repo.save(e);
	}
    
    public List<Product> insertall(List<Product> p){
		return repo.saveAll(p);
	}
    
    public List<Product> getall(){
		return repo.findAll();
	}
    
    public Optional<Product> getbyid(int id) {
		return repo.findById(id);
	}

    public void deletebyid(int id) {
		repo.deleteById(id);	
	}

    public Product updatebyname(Product e) {
		Product ee=repo.findById(e.getId()).orElse(null);
		ee.setDescription(e.getDescription());
		return repo.save(ee);	
	}


}


