import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'converttospaces'
})
export class ConverttospacesPipe implements PipeTransform {

  transform(value: string, character: string): string {
    return value.replace(new RegExp(character, 'g'), '-');
  }
}
