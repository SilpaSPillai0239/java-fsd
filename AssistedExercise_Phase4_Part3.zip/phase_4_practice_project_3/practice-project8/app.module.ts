import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product-list/product-list.component';

import { ChangecolorDirective } from './changecolor.directive';
import { ConverttospacesPipe } from './converttospaces.pipe'

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ChangecolorDirective,
    ConverttospacesPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
