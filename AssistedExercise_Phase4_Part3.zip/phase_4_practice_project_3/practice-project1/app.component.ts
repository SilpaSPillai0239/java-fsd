import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-product-list></app-product-list>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-app';
}
