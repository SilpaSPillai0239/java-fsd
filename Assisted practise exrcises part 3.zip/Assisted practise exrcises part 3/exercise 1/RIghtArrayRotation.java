package project2;

public class RIghtArrayRotation {
	
	
	    public static void main(String[] args) {
	        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	        int num = arr.length;
	        int k = 5;

	   
	        System.out.println("Array in original:");
	        for (int i = 0; i < num; i++) {
	            System.out.print(arr[i] + " ");
	        }
	        System.out.println();

	        
	        for (int i = 0; i < k; i++) {
	            int l = arr[num - 1];
	            for (int j = num - 1; j > 0; j--) {
	                arr[j] = arr[j - 1];
	            }
	            arr[0] = l;
	        }

	       
	        System.out.println("Array after rotation:");
	        for (int i = 0; i < num; i++) {
	            System.out.print(arr[i] + " ");
	        }
	        System.out.println();
	    }
	}



