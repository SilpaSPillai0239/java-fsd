package project2;
import java.util.Stack;
public class StackOperation {
public static void main(String[] args) {
	        Stack<Integer> stack = new Stack<Integer>();

	       
	        stack.push(1);
	        stack.push(2);
	        stack.push(3);
	        stack.push(4);
	        stack.push(5);
	        stack.push(6);
	        stack.push(7);

	        System.out.println("Stack after push: " + stack);

	        
	        int topElement = stack.pop();
	        System.out.println("Element popped from stack: " + topElement);
	        System.out.println("Stack after pop operation: " + stack);

	        
	        int peekElement = stack.peek();
	        System.out.println("Peeked element: " + peekElement);
	        System.out.println("Stack after peek: " + stack);

	        int topElement2 = stack.pop();
	        System.out.println("Element popped from stack: " + topElement2);
	        System.out.println("Stack after pop operation: " + stack);
	        
	        int searchElement = 7;
	        int searchResult = stack.search(searchElement);
	        if (searchResult != -1) {
	            System.out.println(searchElement + " is found at position " + searchResult);
	        } else {
	            System.out.println(searchElement + " is not found in the stack");
	        }
	    }
	}


