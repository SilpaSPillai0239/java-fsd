package project2;
import java.util.LinkedList;
import java.util.Queue;

public class QueueOperation {
	

	
	    public static void main(String[] args) {
	        Queue<Integer> queue = new LinkedList<Integer>();

	       
	        queue.add(1);
	        queue.add(2);
	        queue.add(3);
	        queue.add(4);
	        queue.add(5);
	        queue.add(6);
	        queue.add(7);
	        queue.add(8);




	        System.out.println("Queue after add: " + queue);

	       
	        int Element1 = queue.remove();
	        System.out.println("Removed element: " + Element1);
	        System.out.println("Queue after remove operation: " + queue);

	        
	        int peekElement = queue.peek();
	        System.out.println("Peeked element: " + peekElement);
	        System.out.println("Queue after peek operation: " + queue);
	        
	        int Element2 = queue.remove();
	        System.out.println("Removed element: " +Element2);
	        System.out.println("Queue after remove operation: " + queue);

	       
	        int searchElement = 5;
	        boolean searchResult = queue.contains(searchElement);
	        if (searchResult) {
	            System.out.println(searchElement + " is found in the queue");
	        } else {
	            System.out.println(searchElement + " is not found in the queue");
	        }
	    }
	}



