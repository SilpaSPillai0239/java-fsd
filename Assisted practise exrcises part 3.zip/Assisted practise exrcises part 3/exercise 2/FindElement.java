package project2;
import java.util.Arrays;
public class FindElement {
	

	
	    public static void main(String[] args) {
	        int[] arr = {10, 1, 9, 4, 2, 7, 3, 6, 5,8};
	        int k = 4;

	       
	        System.out.println("Original Array: " + Arrays.toString(arr));

	        
	        Arrays.sort(arr);

	        
	        System.out.println("Sorted Array: " + Arrays.toString(arr));

	        
	        System.out.println("Fourth Smallest Element: " + arr[k - 1]);
	    }
	}


