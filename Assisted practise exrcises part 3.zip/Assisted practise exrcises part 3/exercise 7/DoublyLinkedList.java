package project2;

class Nodule {
    int data;
    Nodule prev;
    Nodule next;
 
    Nodule(int d) {
        data = d;
        prev = null;
        next = null;
    }
}
 
class DoublyLinkedList {
	Nodule head;
 
   
    void insertNode(int value) {
    	Nodule newNode = new Nodule(value);
 
        if (head == null) {
            head = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
    }
 
    
    void ForTraverse() {
    	Nodule temp = head;
 
        System.out.println("Linked list after forward traversal:");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
 
    
    void BackTraverse() {
    	Nodule temp = head;
 
        while (temp != null && temp.next != null)
            temp = temp.next;
 
        System.out.println("Linked list after Backward traversal:");
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.prev;
        }
        System.out.println();
    }
 
    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();
 
        list.insertNode(1);
        list.insertNode(2);
        list.insertNode(3);
        list.insertNode(4);
        list.insertNode(5);
        list.insertNode(6);
        list.insertNode(7);
        list.insertNode(8);
 
        
        list.ForTraverse();
 
       
        list.BackTraverse();
    }
}
