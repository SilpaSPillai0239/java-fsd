package project2;
import java.util.Scanner;
public class RangeSum {
	

	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        
	        System.out.print("Enter the value of number of elements: ");
	        int num = scanner.nextInt();

	        System.out.print("Enter the value of Left range: ");
	        int L = scanner.nextInt();

	        System.out.print("Enter the value of Right range: ");
	        int R = scanner.nextInt();

	       
	        int[] arr = new int[num];

	       
	        System.out.println("Enter the values of the array:");
	        for (int i = 0; i < num; i++) {
	            arr[i] = scanner.nextInt();
	        }

	     
	        int sum = 0;
	        for (int i = L; i <= R; i++) {
	            sum += arr[i];
	        }

	       
	        System.out.println("Sum of elements in the range of Left limit and Right limit: " + sum);

	        scanner.close();
	    }
	}



