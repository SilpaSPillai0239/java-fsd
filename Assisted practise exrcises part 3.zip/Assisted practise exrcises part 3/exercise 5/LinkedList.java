package project2;


	class Nodes {
	    int data;
	    Node next;
	 
	    Nodes(int d) {
	        data = d;
	        next = null;
	    }
	}
	 
	class LinkedList {
	    Node head;
	 
	    void deleteNode(int key) {
	        Node temp = head, prev = null;
	 
	        
	        if (temp != null && temp.data == key) {
	            head = temp.next;
	            return;
	        }
	 
	        
	        while (temp != null && temp.data != key) {
	            prev = temp;
	            temp = temp.next;
	        }
	 
	        
	        if (temp == null)
	            return;
	 
	       
	        prev.next = temp.next;
	    }
	 
	    void printList() {
	        Node currNode = head;
	        System.out.print("LinkedList: ");
	 
	        
	        while (currNode != null) {
	            System.out.print(currNode.data + " ");
	            currNode = currNode.next;
	        }
	    }
	 
	    public static void main(String[] args) {
	    	LinkedList singlylist = new LinkedList();
	 
	        singlylist.head = new Node(1);
	        Node second = new Node(2);
	        Node third = new Node(3);
	        Node fourth = new Node(4);
	        Node fifth = new Node(5);
	        Node sixth = new Node(6);
	        Node seventh = new Node(7);
	        
	        singlylist.head.next = second;
	        second.next = third;
	        third.next = fourth;
	        fourth.next=fifth;
	        fifth.next=sixth;
	        sixth.next=seventh;
	 
	        singlylist.printList(); 	 
	        int key1 = 3;
	        singlylist.deleteNode(key1); 
	        System.out.println();
	        singlylist.printList(); 
	        
	        	 
	        int key2 = 5;
	        singlylist.deleteNode(key2); 
	        System.out.println();
	        singlylist.printList(); 
	        
	    }
	}




