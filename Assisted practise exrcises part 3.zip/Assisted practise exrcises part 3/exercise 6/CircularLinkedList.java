package project2;


	class Node{
	    int data;
	    Node next;
	 
	    Node (int d) {
	        data = d;
	        next = null;
	    }
	}
	 
	public class CircularLinkedList {
	    Node head;
	 
	   
	    void insertNode(int value) {
	        Node newNode = new Node(value);
	 
	        
	        if (head == null) {
	            head = newNode;
	            newNode.next = head;
	        }
	        
	        else if (value < head.data) {
	            Node temp = head;
	            while (temp.next != head)
	                temp = temp.next;
	            temp.next = newNode;
	            newNode.next = head;
	            head = newNode;
	        }
	       
	        else {
	            Node temp = head;
	            while (temp.next != head && temp.next.data < value)
	                temp = temp.next;
	            newNode.next = temp.next;
	            temp.next = newNode;
	        }
	    }
	 
	   
	    void printList() {
	        Node temp = head;
	 
	        if (head != null) {
	            do {
	                System.out.print(temp.data + " ");
	                temp = temp.next;
	            } while (temp != head);
	        }
	    }
	 
	    public static void main(String[] args) {
	        CircularLinkedList list = new CircularLinkedList();
	 
	        
	        list.insertNode(1);
	        list.insertNode(2);
	        list.insertNode(3);
	        list.insertNode(4);
	        list.insertNode(5);
	        list.insertNode(6);
	        list.insertNode(7);
	 
	        
	        list.printList();
	    }
	}



