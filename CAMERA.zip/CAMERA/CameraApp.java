package project;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class InsufficientBalanceException extends Exception {
    
	private static final long serialVersionUID = -7713687990892777648L;

	public InsufficientBalanceException(String message) {
        super(message);
    }
}



class Camera { 
	private String name;
	private String model;
	private double rentPerDay;   
	private boolean rented;
	
public Camera(String name, String model, double rentPerDay) {
    this.name = name;
    this.model = model;
    this.rentPerDay = rentPerDay;
    this.rented = false;
    
}

public String getBrand() {
    return name;
}

public String getModel() {
    return model;
}

public double getRentPerDay() {
    return rentPerDay;
}
public boolean isRented() {
    return rented;
}

public void setRented(boolean rented) {
    this.rented = rented;
}

@Override
public String toString() {
    return name + " (" + model + ") - $" + rentPerDay;
}
}
class MyWallet {
    private double balance;

    public MyWallet(double balance) {
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited " + amount + " to the wallet.");
    }
    public void deduct(double rentPerDay) throws InsufficientBalanceException  {
    	if (rentPerDay>balance) {
    		throw new InsufficientBalanceException("Insufficient balance. Cannot deduct" + rentPerDay);
    	}
        balance -= rentPerDay;
        System.out.println(rentPerDay+"Deducted" + " from the wallet.");
    }

}
public class CameraApp {
    private static List<Camera> cameraList = new ArrayList<>();
    private static MyWallet wallet = new MyWallet(0);
    public static void main(String[] args) {
    	
    	cameraList.add(new Camera("Canon", "EOS R6", 500));
    	cameraList.add(new Camera("Nikon", "Z7 II", 600));
    	cameraList.add(new Camera("Sony", "Alpha A7R IV", 750));
    	cameraList.add(new Camera("Samsung","SM123",1000));
    	
    	WelcomeScreen();
    	
    	
        Scanner scanner = new Scanner(System.in);
        String username, password;
       
        System.out.println("----- Login Page -----");
        System.out.print("Username: ");
        username = scanner.nextLine();
        System.out.print("Password: ");
        password = scanner.nextLine();

        if (authenticate(username, password)) {
            System.out.println("Login Successful!\n");
            mainMenu(scanner);
        } else {
            System.out.println("Login Failed. Invalid username or password.");
        }
    }

    private static boolean authenticate(String username, String password) {
      
        return username.equals("admin") && password.equals("admin123");
    }

    private static void mainMenu(Scanner scanner) {
        int choice;
        do {
            System.out.println("\n----- Main Menu -----");
            System.out.println("1. My Camera");
            System.out.println("2. Rent a Camera");
            System.out.println("3. View All Cameras");
            System.out.println("4. My Wallet");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    myCameraMenu(scanner);
                    break;
                case 2:
                    System.out.println("Option 2: Rent Camera");
                    rentCamera(scanner);
                    
                    break;
                case 3:
                    viewAllCameras();
                    break;
                case 4:
                    System.out.println("Option 4: My Wallet");
                    viewWallet(scanner);
                    break;
                case 5:
                    System.out.println("End of program");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void myCameraMenu(Scanner scanner) {
        int choice;
        do {
            System.out.println("\n----- My Camera -----");
            System.out.println("1. Add Camera");
            System.out.println("2. Remove Camera");
            System.out.println("3. View My Cameras");
            System.out.println("4. Go to Previous Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addCamera(scanner);
                    break;
                case 2:
                    removeCamera(scanner);
                    break;
                case 3:
                    viewMyCameras();
                    break;
                case 4:
                    System.out.println("Going back to the previous menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);
    }

    private static void WelcomeScreen() {
        System.out.println("Welcome to rentmycam.io");
        System.out.println("Camera Rental Applicaton Developed By SILPA S PILLAI");
        System.out.println();
    }  
    
private static void addCamera(Scanner scanner) {
        System.out.println("\n----- Add Camera -----");
        scanner.nextLine(); 
        System.out.print("Enter Camera Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Camera Model: ");
        String model = scanner.nextLine();
        System.out.print("Enter Camera rent per day: ");
        double price = scanner.nextDouble();

        Camera camera = new Camera(name, model, price);
        cameraList.add(camera);
        System.out.println("Camera added successfully!");
   }
private static void removeCamera(Scanner scanner) {
	viewMyCameras();
    System.out.println("\n----- Remove Camera -----");
    System.out.print("Enter the index of the camera to remove: ");
    int index = scanner.nextInt();

    if (index >= 0 && index < cameraList.size()) {
        Camera removedCamera = cameraList.remove(index);
        System.out.println("Camera removed: " + removedCamera);
    } else {
        System.out.println("Invalid index. No camera removed.");
    }
}

private static void viewMyCameras() {
    System.out.println("\n----- List of All Cameras -----");
    if (cameraList.isEmpty()) {
        System.out.println("No cameras available.");
    } else {
    	System.out.format("%-10s %-10s %-10s %-10s %-10s\n","Index", "Brand", "Model", "RentPerDay", "Status");
        System.out.println("--------------------------------------------------------------------------------");
        for (int i = 0; i < cameraList.size(); i++) {
            Camera camera = cameraList.get(i);
            String status = camera.isRented() ? "Rented" : "Available";
            System.out.format("%-5d %-15s %-15s %-10.2f %-10s\n", i,camera.getBrand(), camera.getModel(), camera.getRentPerDay(),status);
        }
    }
}

private static void viewAllCameras() {
	viewMyCameras();
}


private static void rentCamera(Scanner scanner) {
	 int index = 1;
    System.out.println("----- List of Cameras -----");
    System.out.format("%-10s %-10s %-10s  %-10s  %-10s\n","Index", "BrandName", "Model", "RentPerDay","Status");
    for (int i = 0; i < cameraList.size(); i++) {
    	Camera camera = cameraList.get(i);
        String status = camera.isRented() ? "Rented" : "Available";
        System.out.format("%-5d %-15s %-15s %-10.2f %-10s\n",i, camera.getBrand(), camera.getModel(), camera.getRentPerDay(), status);
        
        index++;
    }

    if (index == 1) {
        System.out.println("No cameras available for rent.");
        return;
    }

    System.out.print("Select a camera to rent: ");
    int selection = scanner.nextInt();
    scanner.nextLine(); // Consume newline character

    
    Camera selectedCamera = cameraList.get(selection);
    if (selectedCamera.isRented()) {
        System.out.println("Camera is already rented.");
        return;
    }

    if (wallet.getBalance() >= selectedCamera.getRentPerDay()) {
        try {
			wallet.deduct(selectedCamera.getRentPerDay());
		} catch (InsufficientBalanceException e) {
			System.out.println("Transaction failed: " + e.getMessage());
			e.printStackTrace();
		}
        selectedCamera.setRented(true);
        System.out.println("Camera rented successfully!");
        System.out.println("You rented the following camera:");
        System.out.format("%-15s %-15s  %-15s\n", "Name", "Model", "RentPerDay");
      	System.out.format("%-15s %-15s %-10.2f\n", selectedCamera.getBrand(), selectedCamera.getModel(), selectedCamera.getRentPerDay());
        
        
    }
    else {
    	try {
			wallet.deduct(selectedCamera.getRentPerDay());
		} catch (InsufficientBalanceException e) {
			System.out.println("Transaction failed,You have to deposit sufficient amount of money to rent a camera: " + e.getMessage());
			e.printStackTrace();
		}
    }

}
private static void viewWallet(Scanner scanner) {
    System.out.println("----- My Wallet -----");
    System.out.println("Balance: " + wallet.getBalance());

    System.out.print("Enter amount to deposit: ");
    double amount = scanner.nextDouble();
    scanner.nextLine(); // Consume newline character

    if (amount == 0) {
        System.out.println("Deposit operation cancelled.");
        return;
    }

    wallet.deposit(amount);
}
}
