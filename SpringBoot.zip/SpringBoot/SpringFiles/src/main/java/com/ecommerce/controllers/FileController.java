package com.ecommerce.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.io.FileInputStream;
import java.io.FileOutputStream;
@Controller
public class FileController {

    @GetMapping("/")
    public String uploadForm() {
        return "upload";
    }

    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file, Model model) throws IOException {
        if (!file.isEmpty()) {
            try (InputStream inputStream = file.getInputStream()) {
                // Save the file to a desired location (e.g., in the project directory)
                // Replace "path/to/save/file" with the actual path where you want to save the file
                // You can also perform additional operations like file validation or processing here
            	FileCopyUtils.copy(inputStream, new FileOutputStream("C:\\Users\\HP" + file.getOriginalFilename()));

            }
            model.addAttribute("message", "File uploaded successfully.");
        } else {
            model.addAttribute("message", "Please select a file to upload.");
        }
        return "upload";
    }

    @GetMapping("/download")
    public void downloadFile(HttpServletResponse response) throws IOException {
        // Load the file from a desired location (e.g., in the project directory)
        // Replace "path/to/save/file" with the actual path where you saved the file during upload
        String filePath = "static/dump.txt";
        try (InputStream inputStream = new FileInputStream(filePath);
             OutputStream outputStream = response.getOutputStream()) {
            // Set the response headers
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + "dump.txt" + "\"");

            // Copy the file data to the response output stream
            FileCopyUtils.copy(inputStream, outputStream);
        }
    }
}

