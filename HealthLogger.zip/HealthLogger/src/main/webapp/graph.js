// Fetch the vital data using AJAX
fetch('/getVitalData?patientid=1')
    .then(response => response.json())
    .then(data => {
        const dates = data.map(vital => vital.recordedtime);
        const bplowValues = data.map(vital => vital.bplow);
        const bphighValues = data.map(vital => vital.bphigh);
        const spo2Values = data.map(vital => vital.spo2);

        // Create the chart using Chart.js
        const ctx = document.getElementById('vitalChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: dates,
                datasets: [
                    {
                        label: 'BP Low',
                        data: bplowValues,
                        borderColor: 'red',
                        fill: false
                    },
                    {
                        label: 'BP High',
                        data: bphighValues,
                        borderColor: 'blue',
                        fill: false
                    },
                    {
                        label: 'SPO2',
                        data: spo2Values,
                        borderColor: 'green',
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    },
                    y: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Value'
                        }
                    }
                }
            }
        });
    })
    .catch(error => {
        console.error('Error:', error);
    });
