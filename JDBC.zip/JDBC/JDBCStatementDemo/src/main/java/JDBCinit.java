

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.*;
import java.sql.*;
import java.util.Properties;

/**
 * Servlet implementation class JDBCinit

 */
@WebServlet("/init")
public class JDBCinit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
        out.println("<html><body>");
        
        // Load the DB properties from the config file
        InputStream in = getServletContext().getResourceAsStream("config.properties");
        
        Properties props = new Properties();
        props.load(in);
        
        DBUtil dbutil = new DBUtil(props.getProperty("url"),
       		 props.getProperty("userid"), props.getProperty("password"));
        
        Connection connection = dbutil.getConnection();
        out.println("DB Connection initialized successfully!.<br>");
//        //dbutil.closeConnection();
//        out.println("DB Connection closed.<br>");
        out.println("</body></html>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
}
