package com.ecommerce;

public record DBUtil() {

}
