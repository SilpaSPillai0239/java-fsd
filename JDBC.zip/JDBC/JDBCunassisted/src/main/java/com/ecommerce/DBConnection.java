package com.ecommerce;

public enum DBConnection {

}
