

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class ServletInterfaceDemo
 */
public class ServletInterfaceDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   @Override

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		//System.out.println("Inside init method");
		
		String strABC = config.getInitParameter("ABC");
		System.out.println("Initiazation parameter ABC = "+strABC);	
	}

	/**
	 * @see Servlet#destroy()
	 */
	@Override
	public void destroy() {
		super.destroy();
		System.out.println("Inside destroy method");
	}

	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		out.print("<br> Response from ServletInterfacesDemo<br>");
		
		//access the context init parameters from web.xml
		ServletContext sc = getServletContext();
		String strXYZ = sc.getInitParameter("XYZ");
		out.print("<br>  XYZ Init parameter value is " +strXYZ);	
		
		
	}

	
	

}
