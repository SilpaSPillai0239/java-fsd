

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class TrackHTTPSession
 */
public class TrackHTTPSession extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get or create the HTTP session
        HttpSession session = request.getSession();

        // Check if the session already contains a session ID
        String sessionId = (String) session.getAttribute("sessionId");

        if (sessionId == null || sessionId.isEmpty()) {
            // Generate a new session ID
            sessionId = java.util.UUID.randomUUID().toString();
            // Store the session ID in the session
            session.setAttribute("sessionId", sessionId);
        }

        // Set the response content type
        response.setContentType("text/html");

        // Write the session ID in the response
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Session ID: " + sessionId + "</h2>");
        out.println("</body></html>");
    }
}
